A Pen created at CodePen.io. You can find this one at https://codepen.io/jebbles/pen/MKoYya.

 A set of onboarding screens in HTML/CSS/JS. A personal experiment with layering PNG icons, CSS3 transitions, & flexbox. 